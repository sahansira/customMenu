
/*!
 * jQuery lightweight plugin boilerplate
 * Original author: @sahanhaz
 * Further changes, comments:  @sahanhaz
 * Licensed under the MIT license
 */

// the semi-colon before the function invocation is a safety
// net against concatenated scripts and/or other plugins
// that are not closed properly.
;(function ( $, window, document, undefined ) {

    // undefined is used here as the undefined global
    // variable in ECMAScript 3 and is mutable (i.e. it can
    // be changed by someone else). undefined isn't really
    // being passed in so we can ensure that its value is
    // truly undefined. In ES5, undefined can no longer be
    // modified.

    // window and document are passed through as local
    // variables rather than as globals, because this (slightly)
    // quickens the resolution process and can be more
    // efficiently minified (especially when both are
    // regularly referenced in your plugin).

    // Create the defaults once
    var pluginName = "retina",
        defaults = {
            mobileMenuType : 'offcanvas',
            submenuOpenType : 'dropdown'
        };

    // The actual plugin constructor
    function Plugin( element, options ) {
        this.element = element;

        // jQuery has an extend method that merges the
        // contents of two or more objects, storing the
        // result in the first object. The first object
        // is generally empty because we don't want to alter
        // the default options for future instances of the plugin
        this.options = $.extend( {}, defaults, options) ;

        this._defaults = defaults;
        this._name = pluginName;

        this.init(element, options);
    }

    Plugin.prototype = {

        init: function(element, options) {
            // Place initialization logic here
            // You already have access to the DOM element and
            // the options via the instance, e.g. this.element
            // and this.options
            // you can add more functions like the one below and
            // call them like so: this.yourOtherFunction(this.element, this.options).
            var mobileMenuType = options.mobileMenuType;
            var submenuOpenType = options.submenuOpenType;
            if(mobileMenuType == 'offcanvas') {
                Plugin.prototype.submenuArrangmentOffcanvas(submenuOpenType);
            }
            else if(mobileMenuType == '') {

            }

            $(document).on('click','.hamberger-icon',function(){
                $('body').toggleClass('nav-open');
                $('header').css('height',$('.mobile-off-canvas').height());
            });
            $(document).on('click','.hamberger-icon.offcanvas-icon',function(){
                $('body').removeClass('nav-open');
                $('header').css('height','auto');
                $('.header-wrapper .submenu-off-canvas').removeClass('sub-menu-open');
            });
            $(document).on('click','.submenu-off-canvas .back-button',function(){
                $(this).parents().find('.submenu-off-canvas').removeClass('sub-menu-open');
                $('header').css('height',$('.mobile-off-canvas').height());
            });
            Plugin.prototype.DesktopMenu();
            Plugin.prototype.SubmenuImageToggle();
            Plugin.prototype.MobileDropBlockExpand();
        },
        renderOffcanvas: function (menuType, itemList, id, openType) {
            var placeholder = $('.header-wrapper');
            var topHeader = $('.top-header').html();

            if(menuType == "main-menu") {
                var basicTemplate = $($('#main-menu-template').html());
                basicTemplate.find('.navigation').append(itemList);
                basicTemplate.append("<div class='top-header'>"+topHeader+"</div>");
            }
            else if(menuType == "sub-menu") {
                var basicTemplate = $($('#sub-menu-template').html());
                basicTemplate.attr('id', id);
                basicTemplate.find('.navigation').append(itemList);
            }
            placeholder.append(basicTemplate);
            Plugin.prototype.submenuEventHandler(openType);
        },
        submenuArrangmentOffcanvas: function (submenuOpenType) {
            //var mainMenuList = '<li id="menu0"><a href="#">home</a></li>';
            var mainMenuList = '';
            var subMenuList = '';
            var itemCounter = 1;
            $('nav > ul > li').each(function() {
              var parentElement = $(this);
              parentText = parentElement.find('> a').text();
              parentLink = parentElement.find('> a').attr('href');
              if ((parentLink == null) || (parentLink == 'undefined')) {
                  parentLink = '#';
              }
              if(submenuOpenType == 'dropdown') {
                  var subMenu = '';
                  if ($(this).find('.sub-menu').length > 0) {
                      if (parentElement.hasClass('hide-link')) {
                          mainMenuList = mainMenuList + '<li id="menu' + itemCounter + '" class="has-sub-menu"><a>' + parentText + '</a>';
                      }
                      else {
                          mainMenuList = mainMenuList + '<li id="menu' + itemCounter + '" class="has-sub-menu"><a href="' + parentLink + '">' + parentText + '</a>';
                      }
                      //mainMenuList = mainMenuList + '<li id="menu' + itemCounter + '" class="has-sub-menu"><a href="' + parentLink + '">' + parentText + '</a>';
                      var subMenu = "<ul class='sub-menu' style=''>";
                      parentElement.find('.sub-menu li').each(function () {
                          subMenu += "<li>";
                          subMenu += "<a href= '" + $(this).find('a').attr('href') + "' >";
                          subMenu += "<span class='submenu-content'>";
                          subMenu += "<span class='title'>" + $(this).find('.title').text() + "</span>";
                          subMenu += "<span class='description'>" + $(this).find('.description').text() + "</span>";
                          subMenu += "</span>";
                          if ($(this).find('.sub-image').length > 0) {
                              subMenu += "<span class='sub-image'>";
                              subMenu += "<img src='" + $(this).find('.sub-image img').attr('src') + "' alt=''>";
                              subMenu += "</span>";
                              subMenu += "</a>";
                              subMenu += "</li>";
                          }
                          else {
                              subMenu += "</a>";
                              subMenu += "</li>";
                          }
                      });
                      subMenu = subMenu + "</ul>";
                  }
                  else {
                      mainMenuList = mainMenuList + '<li id="menu' + itemCounter + '"><a href="' + parentLink + '">' + parentText + '</a>';
                  }
                  mainMenuList = mainMenuList + subMenu + "</li>";
              }
              else if(submenuOpenType == 'slide') {
                  mainMenuList = mainMenuList + '<li id="menu'+itemCounter+'"><a href="'+parentLink+'">'+parentText+'</a></li>';
                  if(parentElement.find('.sub-menu').length > 0) {
                    var sumMenu = parentElement.find('.sub-menu').clone();
                    Plugin.prototype.renderOffcanvas("sub-menu", sumMenu, itemCounter, submenuOpenType);
                  }
              }
              itemCounter++;
            });
            var mainMenu = "<ul>"+mainMenuList+"</ul>";
            Plugin.prototype.renderOffcanvas("main-menu", mainMenu, 0, submenuOpenType);
        },
        submenuEventHandler: function(submenuOpenType) {
            if(submenuOpenType == 'dropdown') {
                Plugin.prototype.dropmenuOnClick();
            }
            else if(submenuOpenType == 'slide') {
                Plugin.prototype.slidemenuOnClick();
            }
        },
        dropmenuOnClick: function () {
            $(document).on('click', '.mobile-off-canvas .navigation li', function () {
                $(this).find('a').toggleClass('fold');
                $(this).toggleClass('active-fold');
                setTimeout(function () {
                    $('header').css('height', $('.mobile-off-canvas').height());
                }, 500);
            });
        },
        slidemenuOnClick: function () {
            $(document).on('click', '.mobile-off-canvas .navigation li', function () {
                $(this).find('.sub-menu').slideToggle();
                setTimeout(function () {
                    $('header').css('height', $('.mobile-off-canvas').height());
                }, 500);
                var thisId = $(this).attr('id');
                var thisSubId = thisId.split("menu")[1];
                $('.header-wrapper .submenu-off-canvas').each(function() {
                   if($(this).attr('id') == 0) {
                       $('body').toggleClass('nav-open');
                   }
                   else if($(this).attr('id') == thisSubId) {
                       $('header').css('height',$(this).height());
                       $(this).addClass('sub-menu-open');
                   }
                });
            });
        },
        mainHeaderHeightChange: function () {
            var winWidth = $(window).width();
            if(winWidth > 640) {
                $('body').removeClass('nav-open');
                $('header').css('height','auto');
                $('.header-wrapper .submenu-off-canvas').removeClass('sub-menu-open');
            }
        },

        SubmenuImageToggle: function () {
            var winWidth = $(window).width();
            if(winWidth < 640) {
                $('.sub-menu .sub-image').each(function() {
                    $(this).find('img').attr('src', $(this).find('img').data('mobile'));
                });
            }
            else {
                $('.sub-menu .sub-image').each(function() {
                    $(this).find('img').attr('src', $(this).find('img').data('desktop'));
                });
            }
        },
        DesktopMenu: function () {
            $('header .main-header nav >ul >li').on('mouseover',function(){
                var winWidth = $(window).width();
                var thisElement = $(this).find('.submenu-wrapper');
                if (winWidth > 640) {
                    $(this).find('.submenu-wrapper').addClass('active').delay(1000);
                    //$(this).find('.submenu-wrapper').delay(500).queue(function () {
                    //    $(this).addClass('active').clearQueue();
                    //});
                }
            });
            $('header .main-header nav >ul >li').on('mouseleave',function(){
                var winWidth = $(window).width();
                var thisElement = $(this).find('.submenu-wrapper');
                if (winWidth > 640) {
                    $(this).find('.submenu-wrapper').removeClass('active');
                }
            });
            $(document).mouseleave(function (e) {
                setTimeout(function () {
                    var menuitem = $(".menu-item");
                    if (!menuitem.is(e.target) && menuitem.has(e.target).length === 0) {
                        $(this).find('.sub-menu').removeClass('active');
                    }
                }, 500);

            });
        },
        MobileDropBlockExpand: function () {
            $(".mobile-drop-block").on('click',function(){
                $(this).toggleClass('expand');
                $(this).parent().toggleClass('drop-open');
            });
        }
    };

    // A really lightweight plugin wrapper around the constructor,
    // preventing against multiple instantiations
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, "plugin_" + pluginName)) {
                $.data(this, "plugin_" + pluginName,
                new Plugin( this, options ));
            }
        });
    };

})( jQuery, window, document );
