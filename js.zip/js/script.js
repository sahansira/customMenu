$(document).ready(function () {
    $('.header-wrapper').retina({
        combinedMenu : ['.top-header','top-header'],
        mobileMenuType : 'offcanvas',
        submenuOpenType : 'dropdown'
    });
});
$(window).resize(function() {
    // SubmenuImageToggle.init();
    // Offcanvas.mainHeaderHeightChange();
});
